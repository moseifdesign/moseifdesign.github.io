// ==========================================================================
// MOHAMED SEIF — REFINED JAVASCRIPT ENGINE
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {

  // 1. MINIMAL CUSTOM CURSOR (DOT + RING, NO WORDS)
  const dot = document.getElementById('cursorDot');
  const ring = document.getElementById('cursorRing');
  let mX = window.innerWidth / 2, mY = window.innerHeight / 2;
  let rX = mX, rY = mY;

  if (window.matchMedia('(pointer: fine)').matches) {
    document.addEventListener('mousemove', (e) => {
      mX = e.clientX;
      mY = e.clientY;
    });

    function renderCursor() {
      rX += (mX - rX) * 0.22;
      rY += (mY - rY) * 0.22;

      dot.style.left = mX + 'px';
      dot.style.top = mY + 'px';
      ring.style.left = rX + 'px';
      ring.style.top = rY + 'px';

      requestAnimationFrame(renderCursor);
    }
    requestAnimationFrame(renderCursor);

    // Dynamic scale states
    document.querySelectorAll('a, button, input, select, textarea, .work-entry-card, .service-entry-row').forEach(el => {
      el.addEventListener('mouseenter', () => ring.classList.add('is-hovering'));
      el.addEventListener('mouseleave', () => ring.classList.remove('is-hovering'));
    });

    document.querySelectorAll('.editorial-btn.primary, .nav-cta-btn').forEach(btn => {
      btn.addEventListener('mouseenter', () => ring.classList.add('is-cta'));
      btn.addEventListener('mouseleave', () => ring.classList.remove('is-cta'));
    });
  }

  // 2. Scroll-driven depth orbit. Release following sections only after every card fades.
  const fragmentsViewport = document.getElementById('fragmentsViewport');
  const fragments = Array.from(document.querySelectorAll('.hero-fragment'));
  const heroSection = document.getElementById('home');
  const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
  const stage = document.createElement('div');
  stage.className = 'hero-scroll-stage';
  heroSection.removeAttribute('id');
  stage.id = 'home';
  heroSection.before(stage);
  stage.append(heroSection);
  const following = Array.from(document.querySelectorAll('body > section, body > footer'));
  let travel = 1, stageTop = 0, smoothProgress = 0, lastTime = 0;
  let startedAt = null;
  const clamp = (v, min = 0, max = 1) => Math.min(max, Math.max(min, v));
  const ease = v => v * v * (3 - 2 * v);
  function measureHero() {
    travel = motionPreference.matches ? 180 : Math.max(1600, window.innerHeight * 2.5);
    stage.style.height = `${heroSection.offsetHeight + travel + 120}px`;
    stageTop = stage.getBoundingClientRect().top + window.scrollY;
  }
  let previousGate;
  function gateContent(hidden) {
    if (hidden === previousGate) return;
    previousGate = hidden;
    following.forEach(el => {
      el.classList.toggle('awaiting-hero', hidden);
      el.inert = hidden;
    });
  }
  // Fixed, art-directed scatter: no random jumps on resize or reverse scroll.
  const layout = [
    [-164,.91,-.27,.83,-12],[-128,.72,-.69,.65,7],[-83,.94,-.79,.76,-5],
    [-39,.82,-.56,.90,11],[4,1.00,-.12,.71,-8],[44,.77,.46,.92,6],
    [81,.97,.76,.74,-10],[116,.65,.38,.61,9],[148,.89,.62,.87,-4],
    [187,.74,.04,.66,12],[224,.96,-.49,.73,-7],[291,.57,.13,.58,5]
  ];
  fragments.forEach((fragment,i) => {
    fragment.setAttribute('role','button');
    fragment.tabIndex = 0;
    fragment.setAttribute('aria-label', `Open project ${i % 4 + 1}`);
    fragment.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault(); fragment.click();
      }
    });
  });
  function renderHero(now) {
    if (startedAt === null) startedAt = now;
    const dt = Math.min(64, now - (lastTime || now));
    lastTime = now;
    const reduced = motionPreference.matches;
    const target = clamp((window.scrollY - stageTop) / travel);
    smoothProgress += (target - smoothProgress) * (reduced ? 1 : 1 - Math.exp(-dt / 150));
    if (Math.abs(target - smoothProgress) < 0.0001) smoothProgress = target;
    const fade = ease(clamp((smoothProgress - 0.73) / 0.25));
    const turn = reduced ? 0 : clamp(smoothProgress / 0.88) * Math.PI * 2;
    const radiusX = Math.min(window.innerWidth * 0.46, 840);
    const radiusY = Math.min(heroSection.offsetHeight * 0.31, 310);
    fragments.forEach((fragment, i) => {
      const [degrees, radius, vertical, size, tilt] = layout[i];
      const base = degrees * Math.PI / 180;
      const angle = base + turn;
      const depth = Math.sin(angle);
      const entrance = reduced ? 1 : 1 - Math.pow(1 - clamp((now - startedAt - i * 32) / 1400), 3);
      const floatX = reduced ? 0 : Math.sin(now * 0.00038 + i * 0.83) * 4;
      const floatY = reduced ? 0 : Math.cos(now * 0.00044 + i * 1.17) * 5;
      const spread = 1 + fade * 0.24;
      const x = Math.cos(angle) * radiusX * radius * spread + floatX;
      const y = (vertical * radiusY + Math.sin(angle - base) * radiusY * (0.13 + (i % 3) * 0.06)) * spread + floatY;
      const scale = size * (0.94 + (depth + 1) * 0.06) * (0.92 + entrance * 0.08);
      fragment.style.opacity = String(entrance * (1 - fade) * (0.68 + (depth + 1) * 0.13));
      fragment.style.zIndex = String(1 + i);
      fragment.style.transform = `translate(-50%, -50%) translate3d(${x}px, ${y + (1 - entrance) * 22}px, 0) rotate(${tilt + (reduced ? 0 : Math.sin(angle) * 2)}deg) scale(${scale})`;

    });
    const hidden = fade >= 1;
    fragmentsViewport.classList.toggle('is-hidden', hidden);
    // No independent visibility transition: cards and next content switch in the same frame.
    gateContent(!hidden);
    requestAnimationFrame(renderHero);
  }
  measureHero();
  // Resolve direct section links after adding the pinned hero's scroll space.
  if (location.hash.length > 1) requestAnimationFrame(() => {
    const target = document.getElementById(location.hash.slice(1));
    if (target) target.scrollIntoView({behavior:'instant', block:'start'});
  });
  gateContent(window.scrollY < stageTop + travel);
  window.addEventListener('resize', measureHero, { passive: true });
  motionPreference.addEventListener('change', measureHero);
  if (document.fonts) document.fonts.ready.then(measureHero);
  requestAnimationFrame(renderHero);

  // 3. TOP SECTION INDICATOR (SCROLL SPY)
  const trackedSections = document.querySelectorAll('.hero-scroll-stage, section[id]');
  const navLinks = document.querySelectorAll('.nav-link-item');

  const navObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navLinks.forEach(link => {
          if (link.getAttribute('data-section') === id) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });
      }
    });
  }, { rootMargin: '-25% 0px -50% 0px' });

  trackedSections.forEach(sec => navObserver.observe(sec));

  // 4. PROJECT CASE STUDIES DATA (8 PROJECTS, 10 THUMBNAILS EACH)
  const projects = [
    {
      index: "01 / 08",
      title: "I Spent 50 Hours In A Supermax Cell",
      category: "CHALLENGE · HIGH STAKES",
      service: "Single Thumbnail + A/B Testing",
      year: "2026",
      desc: "Engineered for claustrophobic tension with isolated rim lighting and direct pupil focal lock. Tested across 12 competitor feeds, yielding a +21.2% click-through rate lift.",
      metrics: [
        "Focal Lock: Direct emotional gaze anchoring the primary third",
        "Feed Legibility: Certified at 120px mobile scale under dark & light modes",
        "Performance: +21.2% CTR lift over channel 90-day baseline"
      ],
      gradient: "linear-gradient(135deg, #261720 0%, #0e090d 100%)",
      thumbs: [
        { name: "01 · Master Final Upload", hook: "Intense Face + Bars Close-up", bg: "linear-gradient(135deg, #261720, #0e090d)" },
        { name: "02 · A/B Variant: Cold Blue", hook: "Cold Steel Palette Test", bg: "linear-gradient(135deg, #121c24, #080d12)" },
        { name: "03 · Guard Tower Isolation", hook: "CCTV Security Angle", bg: "linear-gradient(135deg, #1c1424, #0a0812)" },
        { name: "04 · 120px Mobile Screen Pass", hook: "Small-Screen Contrast Pass", bg: "linear-gradient(135deg, #241414, #0f0808)" },
        { name: "05 · Extreme Pupil Lock", hook: "Direct Viewer Eye Contact", bg: "linear-gradient(135deg, #1a2216, #090f08)" },
        { name: "06 · Concrete Texture Macro", hook: "Physical Isolation Atmosphere", bg: "linear-gradient(135deg, #2b2210, #130f06)" },
        { name: "07 · Infrared Surveillance Cam", hook: "Monochromatic Night Vision", bg: "linear-gradient(135deg, #0e2417, #06120b)" },
        { name: "08 · Alternate Title Pairing", hook: "Optimized for '50 HOURS IN CELL'", bg: "linear-gradient(135deg, #251221, #0f070e)" },
        { name: "09 · Split Time Comparison", hook: "Hour 01 vs Hour 50 Fatigue", bg: "linear-gradient(135deg, #1b1b22, #0d0d12)" },
        { name: "10 · Raw Plate vs Final Grade", hook: "Production Layer Grading", bg: "linear-gradient(135deg, #201a14, #100c0a)" }
      ]
    },
    {
      index: "02 / 08",
      title: "Pro 2v2 Championship Finals",
      category: "GAMING & ESPORTS",
      service: "Thumbnail Pack",
      year: "2026",
      desc: "High-contrast 3D character extraction, clean weapon silhouette separation, and tournament tension designed for Battle Royale esports feeds.",
      metrics: [
        "Silhouette Craft: Clean 3D player extraction with neon rim lights",
        "Color Discipline: Zero muddy midtones to stand out on dark mobile feeds",
        "Performance: +18.4% CTR lift across tournament series"
      ],
      gradient: "linear-gradient(135deg, #14202b 0%, #0d1217 100%)",
      thumbs: [
        { name: "01 · Championship Win Render", hook: "3D Duo Model Silhouette", bg: "linear-gradient(135deg, #14202b, #0d1217)" },
        { name: "02 · Trophy Golden Hour", hook: "Victory & Wealth Lighting", bg: "linear-gradient(135deg, #292410, #120f06)" },
        { name: "03 · Red Storm Overtime", hook: "High Tension Final Circle", bg: "linear-gradient(135deg, #281414, #120808)" },
        { name: "04 · Mythic Weapon Flare", hook: "Golden Weapon Focal Point", bg: "linear-gradient(135deg, #122421, #061210)" },
        { name: "05 · Pro Facecam Clutch", hook: "Extreme Clutch Expression", bg: "linear-gradient(135deg, #201428, #0d0714)" },
        { name: "06 · 30-Kill Counter Hook", hook: "High Kill Game Story", bg: "linear-gradient(135deg, #241812, #100b07)" },
        { name: "07 · Dark Mode Feed Pass", hook: "Mobile Feed Dark Theme Test", bg: "linear-gradient(135deg, #111b24, #080d12)" },
        { name: "08 · Rival Duo Split Stare", hook: "Split Red vs Blue Composition", bg: "linear-gradient(135deg, #1f1424, #0c0812)" },
        { name: "09 · Clean Silhouette Minimap", hook: "Zero Clutter Esports Concept", bg: "linear-gradient(135deg, #16241a, #08120b)" },
        { name: "10 · 120px Screen Verification", hook: "Verified Small-Screen Read", bg: "linear-gradient(135deg, #1f1b24, #0e0a12)" }
      ]
    },
    {
      index: "03 / 08",
      title: "Digital Exposé: Dark Side Of Influencers",
      category: "DOCUMENTARY / ESSAY",
      service: "Single Thumbnail",
      year: "2026",
      desc: "Documentary-grade intrigue with subtle evidence overlays, low-key lighting, and zero clickbait tropes, earning genuine curiosity clicks.",
      metrics: [
        "Art Direction: Editorial noir lighting with forensic dossier overlays",
        "Psychology: Curiosity gap triggered without looking sensationalist",
        "Performance: +16.9% CTR lift on longform 45-minute video essay"
      ],
      gradient: "linear-gradient(135deg, #2b1720 0%, #140d12 100%)",
      thumbs: [
        { name: "01 · The Redacted Dossier", hook: "Classified Document Aesthetic", bg: "linear-gradient(135deg, #2b1720, #140d12)" },
        { name: "02 · Low-Key Noir Portrait", hook: "Single Shaft Studio Lighting", bg: "linear-gradient(135deg, #18181f, #0a0a0f)" },
        { name: "03 · Shattered Phone Screen", hook: "Broken Reputation Metaphor", bg: "linear-gradient(135deg, #142028, #080e12)" },
        { name: "04 · Golden Statue Crumbling", hook: "Ego & Downfall Metaphor", bg: "linear-gradient(135deg, #252010, #100d05)" },
        { name: "05 · Courtroom Tape Stamp", hook: "Legal Reality Verification", bg: "linear-gradient(135deg, #281414, #120808)" },
        { name: "06 · Follower Count Plunge", hook: "Graphic Data Storytelling", bg: "linear-gradient(135deg, #1f1428, #0c0714)" },
        { name: "07 · The Empty Penthouse", hook: "Luxury Isolation Angle", bg: "linear-gradient(135deg, #14261f, #07130e)" },
        { name: "08 · Secret Whistleblower", hook: "Silhouetted Identity Hook", bg: "linear-gradient(135deg, #221a14, #0f0a06)" },
        { name: "09 · 120px Mobile Squint Benchmark", hook: "Editorial Feed Clarity Test", bg: "linear-gradient(135deg, #191922, #0a0a10)" },
        { name: "10 · High-Contrast Master", hook: "Approved Production Master", bg: "linear-gradient(135deg, #281720, #12090e)" }
      ]
    },
    {
      index: "04 / 08",
      title: "SWAT Tactical Midnight Bodycam",
      category: "GAMING / BODYCAM",
      service: "Thumbnail Pack",
      year: "2026",
      desc: "Fisheye optical curvature, authentic HUD military camera timestamps, and jump-scare storytelling calibrated for simulation feeds.",
      metrics: [
        "Camera Mechanics: Fisheye optical distortion and authentic HUD font",
        "Lighting: Infrared flashlight illumination creating immediate panic",
        "Performance: +19.7% CTR lift and 2.4x channel average viewership"
      ],
      gradient: "linear-gradient(135deg, #1b281f 0%, #0d1410 100%)",
      thumbs: [
        { name: "01 · Fisheye Corner Breach", hook: "Doorway Creature Hook", bg: "linear-gradient(135deg, #1b281f, #0d1410)" },
        { name: "02 · Infrared Weapon Flare", hook: "Direct Weapon Flash Lighting", bg: "linear-gradient(135deg, #152220, #081210)" },
        { name: "03 · 03:42 AM HUD Timestamp", hook: "Law Enforcement Bodycam", bg: "linear-gradient(135deg, #1a1a24, #090912)" },
        { name: "04 · Silhouette In Window", hook: "Micro Horror Discovery", bg: "linear-gradient(135deg, #221714, #100907)" },
        { name: "05 · Glitch Compression", hook: "Artifact Distortion Hook", bg: "linear-gradient(135deg, #241424, #100710)" },
        { name: "06 · Hallway Smoke Mist", hook: "Volumetric Shadow Lighting", bg: "linear-gradient(135deg, #13241b, #07120c)" },
        { name: "07 · Heart Rate 180 BPM", hook: "Officer Panic Indicator", bg: "linear-gradient(135deg, #261414, #110707)" },
        { name: "08 · Concrete Texture Floor", hook: "Ground Depth of Field", bg: "linear-gradient(135deg, #1c2016, #0d1008)" },
        { name: "09 · 120px Mobile Pass", hook: "Instant Horror Read", bg: "linear-gradient(135deg, #171f24, #090e12)" },
        { name: "10 · Approved Viral Master", hook: "+19.7% CTR Final Delivery", bg: "linear-gradient(135deg, #1a251e, #0b120d)" }
      ]
    },
    {
      index: "05 / 08",
      title: "$1 vs $100,000 Island Vacation",
      category: "CHALLENGE / CONTRAST",
      service: "Single Thumbnail",
      year: "2026",
      desc: "Instant 50/50 visual juxtaposition that communicates wealth contrast in under 0.2 seconds on mobile feeds.",
      metrics: [
        "Composition: Razor-sharp center split dividing poverty vs luxury",
        "Color Separation: Dirty mud-brown left vs warm golden-cyan right",
        "Performance: +22.5% CTR lift and 4.2M views in first 7 days"
      ],
      gradient: "linear-gradient(135deg, #2a2414 0%, #141108 100%)",
      thumbs: [
        { name: "01 · 50/50 Dirt vs Gold Split", hook: "Ultra Contrast in 0.2s", bg: "linear-gradient(135deg, #2a2414, #141108)" },
        { name: "02 · Wooden Raft vs Superyacht", hook: "Extreme Scale Disparity", bg: "linear-gradient(135deg, #142028, #081014)" },
        { name: "03 · Rainstorm vs Golden Sunset", hook: "Weather Division", bg: "linear-gradient(135deg, #241620, #10080d)" },
        { name: "04 · Canned Beans vs Caviar Plate", hook: "Food Value Perception", bg: "linear-gradient(135deg, #202414, #0d1008)" },
        { name: "05 · Island Aerial Perspective", hook: "Deserted Sandbar vs Resort", bg: "linear-gradient(135deg, #142422, #071210)" },
        { name: "06 · Hypothermic vs Sunburned", hook: "Dual Facial Reaction", bg: "linear-gradient(135deg, #281814, #120907)" },
        { name: "07 · $1.00 vs $100,000 Price Stamp", hook: "Numerical Contrast Hook", bg: "linear-gradient(135deg, #1a1524, #0a0712)" },
        { name: "08 · Campfire vs Villa Chandelier", hook: "Luminance Contrast", bg: "linear-gradient(135deg, #242214, #100f07)" },
        { name: "09 · 120px Squint Benchmark", hook: "Zero Confusion on Mobile", bg: "linear-gradient(135deg, #1e1925, #0c0912)" },
        { name: "10 · Master Channel Record", hook: "+22.5% CTR Delivery", bg: "linear-gradient(135deg, #282214, #120f07)" }
      ]
    },
    {
      index: "06 / 08",
      title: "The Podcast That Broke The Internet",
      category: "PODCAST / TALK SHOW",
      service: "Monthly Retainer",
      year: "2026",
      desc: "Micro-expression retouching, studio microphone depth, and face-centric curiosity calibrated for talk show feeds.",
      metrics: [
        "Facial Retouching: Subtle micro-expression enhancement with zero plastic look",
        "Studio Depth: Calibrated background bokeh matching Shure microphone focal plane",
        "Performance: +17.3% CTR lift and recurring visual language retention"
      ],
      gradient: "linear-gradient(135deg, #24142a 0%, #120a15 100%)",
      thumbs: [
        { name: "01 · Shocked Reaction Cutout", hook: "Micro-Expression Retouched", bg: "linear-gradient(135deg, #24142a, #120a15)" },
        { name: "02 · Studio Warm Rim Lighting", hook: "High End Talk Ambiance", bg: "linear-gradient(135deg, #241e14, #120d08)" },
        { name: "03 · Shure SM7B Mic Silhouette", hook: "Authority Anchor", bg: "linear-gradient(135deg, #141c24, #080d12)" },
        { name: "04 · Head in Hands Emotion", hook: "Regret & Revelation Hook", bg: "linear-gradient(135deg, #261418, #11070a)" },
        { name: "05 · Dual Host vs Guest Stare", hook: "High Tension Conversation", bg: "linear-gradient(135deg, #182414, #091207)" },
        { name: "06 · Unreleased Clip Border", hook: "Exclusive Leak Angle", bg: "linear-gradient(135deg, #1d1428, #0b0712)" },
        { name: "07 · Studio Foam Backdrop", hook: "Authentic Production Environment", bg: "linear-gradient(135deg, #142421, #071210)" },
        { name: "08 · Quote Teaser Hook", hook: "'I Regret Everything'", bg: "linear-gradient(135deg, #242416, #101007)" },
        { name: "09 · 120px Small-Screen Pass", hook: "Face Retains High Contrast", bg: "linear-gradient(135deg, #1e1724, #0c0812)" },
        { name: "10 · Final Production Deliverable", hook: "Multi-Million Impression Win", bg: "linear-gradient(135deg, #24152a, #100914)" }
      ]
    },
    {
      index: "07 / 08",
      title: "Building An 8-Bit CPU In Minecraft",
      category: "GAMING / SANDBOX",
      service: "Single Thumbnail",
      year: "2026",
      desc: "Monumental isometric scale, redstone circuit glow, and unbelievable architectural scale communicating complexity.",
      metrics: [
        "Isometric Scale: Vast depth-of-field illustrating 400,000 redstone blocks",
        "Illumination: Custom glow grading on repeater logic lines",
        "Performance: +15.8% CTR lift in technical gaming vertical"
      ],
      gradient: "linear-gradient(135deg, #15272a 0%, #0a1315 100%)",
      thumbs: [
        { name: "01 · Epic Redstone Mega Circuit", hook: "Massive Architectural Scale", bg: "linear-gradient(135deg, #15272a, #0a1315)" },
        { name: "02 · Screen Rendering In-Game", hook: "Playable Pong on Giant Screen", bg: "linear-gradient(135deg, #142216, #071208)" },
        { name: "03 · Sunset Isometric Depth", hook: "Golden Angle Architecture", bg: "linear-gradient(135deg, #252014, #120e07)" },
        { name: "04 · 8-Bit CPU Logic Gates", hook: "Technical Wonder Hook", bg: "linear-gradient(135deg, #24141d, #12080d)" },
        { name: "05 · Player Floating in Vast Void", hook: "Scale Comparison Hook", bg: "linear-gradient(135deg, #141824, #080a12)" },
        { name: "06 · Neon Repeater Lines", hook: "High Contrast Neon Circuits", bg: "linear-gradient(135deg, #261614, #120907)" },
        { name: "07 · 'IT ACTUALLY BOOTS' Label", hook: "Curiosity Premise Hook", bg: "linear-gradient(135deg, #1e1426, #0c0712)" },
        { name: "08 · Night Horizon Lighting", hook: "Ultra Clean Lighting Separation", bg: "linear-gradient(135deg, #142422, #071210)" },
        { name: "09 · 120px Squint Benchmark", hook: "Readable Micro Architecture", bg: "linear-gradient(135deg, #152528, #091214)" },
        { name: "10 · Master Upload Asset", hook: "+15.8% CTR Channel Record", bg: "linear-gradient(135deg, #142728, #081415)" }
      ]
    },
    {
      index: "08 / 08",
      title: "Fixing Your Broken Attention Span",
      category: "ESSAY / PSYCHOLOGY",
      service: "Single Thumbnail",
      year: "2026",
      desc: "Ruthless minimalist metaphor with zero clutter, commanding attention in academic and educational feeds.",
      metrics: [
        "Radical Minimalism: Single stark metaphor without unnecessary floating icons",
        "Color Palette: Deep monochrome with singular laser focus beam",
        "Performance: +20.1% CTR lift on self-improvement audience"
      ],
      gradient: "linear-gradient(135deg, #2a1515 0%, #140a0a 100%)",
      thumbs: [
        { name: "01 · Monochromatic Burnout", hook: "Ruthless Minimalist Metaphor", bg: "linear-gradient(135deg, #2a1515, #140a0a)" },
        { name: "02 · 10h Dopamine Detox Timer", hook: "Time Pressure Curiosity", bg: "linear-gradient(135deg, #161a24, #080a12)" },
        { name: "03 · Golden Laser Focus Beam", hook: "Laser Clarity vs Chaos", bg: "linear-gradient(135deg, #242214, #111006)" },
        { name: "04 · Phone Locked in Safe", hook: "Extreme Self-Control Hook", bg: "linear-gradient(135deg, #14241e, #07120e)" },
        { name: "05 · Neuroscience Neuron Reset", hook: "Scientific Authority Angle", bg: "linear-gradient(135deg, #241424, #100710)" },
        { name: "06 · Blank Journal Dark Room", hook: "Deep Work Focus Aesthetic", bg: "linear-gradient(135deg, #161e24, #080e12)" },
        { name: "07 · Notification Chaos", hook: "Relatable Pain Point Hook", bg: "linear-gradient(135deg, #241814, #100906)" },
        { name: "08 · Single White Dot in Void", hook: "Ultra Radical Minimalism", bg: "linear-gradient(135deg, #15151b, #09090d)" },
        { name: "09 · 120px Small-Screen Pass", hook: "Dominates Educational Feeds", bg: "linear-gradient(135deg, #261616, #120808)" },
        { name: "10 · Approved Master Packaging", hook: "+20.1% CTR Longform Winner", bg: "linear-gradient(135deg, #281414, #120707)" }
      ]
    }
  ];


  // Supplied artwork: one actual image per project, with no invented variants.
  const suppliedArtwork = [{"src": "horror.webp", "alt": "Horror gaming thumbnail"}, {"src": "chocolate.webp", "alt": "Chocolate comparison thumbnail"}, {"src": "farm.webp", "alt": "Farm challenge thumbnail"}, {"src": "day-one.webp", "alt": "Day one challenge thumbnail"}];
  const artworkNotes = [
    ['A close-up reaction paired with a dark haunted-house scene and a threatening character.', 'Subject: Horror gaming', 'Composition: Face and character contrast'],
    ['A side-by-side chocolate comparison with a central reaction and clearly separated product packaging.', 'Subject: Chocolate comparison', 'Composition: Central face with two products'],
    ['A farming scene combining a close-up portrait, a red barn and a foreground pitchfork.', 'Subject: Farming challenge', 'Composition: Portrait against a bright outdoor setting'],
    ['A day-one challenge image with a dollar bill, bold lettering and a portrait against green grass.', 'Subject: Day-one challenge', 'Composition: Text and dollar bill opposite the portrait']
  ];
  suppliedArtwork.forEach((art, i) => {
    const p = projects[i];
    p.image = art.src; p.alt = art.alt;
    p.desc = artworkNotes[i][0]; p.metrics = artworkNotes[i].slice(1);
    p.thumbs = [{ image: art.src, alt: art.alt, bg: p.gradient }];
  });
  function showArtwork(element, src, alt) {
    element.replaceChildren();
    if (!src) return;
    const image = document.createElement('img');
    image.src = src; image.alt = alt || ''; image.width = 1920; image.height = 1080;
    image.className = 'project-art-image'; image.decoding = 'async';
    element.appendChild(image);
  }

  // 5. PROJECT VIEW OVERLAY LOGIC
  const overlay = document.getElementById('projectOverlay');
  const closeBtn = document.getElementById('overlayCloseBtn');
  const oIndex = document.getElementById('overlayIndex');
  const oBannerBg = document.getElementById('overlayBannerBg');
  const oContext = document.getElementById('overlayContext');
  const oMetrics = document.getElementById('overlayMetrics');
  const oBriefBtn = document.getElementById('overlayBriefBtn');
  const prevProjBtn = document.getElementById('prevProjectBtn');
  const nextProjBtn = document.getElementById('nextProjectBtn');

  // Carousel inside overlay
  const itCount = document.getElementById('iterationsCount');
  const itCanvasBg = document.getElementById('itCanvasBg');
  const itStrip = document.getElementById('iterationsStrip');
  const itPrev = document.getElementById('itPrevBtn');
  const itNext = document.getElementById('itNextBtn');

  let activePIndex = 0;
  let activeSlide = 0;

  window.openProjectModal = function(idx) {
    activePIndex = idx;
    activeSlide = 0;
    const p = projects[idx];

    oIndex.textContent = `PROJECT ${p.index}`;
    oBannerBg.style.background = p.gradient;
    showArtwork(oBannerBg, p.image, p.alt);
    document.querySelector(".os-right .os-heading").textContent = p.image ? "Artwork Details" : "Packaging Metrics";
    document.querySelector(".iterations-header .os-heading").textContent = p.image ? "Artwork" : "Packaging Variations (10 in File)";
    oContext.textContent = p.desc;
    oBriefBtn.setAttribute('data-scope', p.service);

    oMetrics.innerHTML = p.metrics.map(m => {
      const parts = m.split(': ');
      return `<li><strong>${parts[0]}:</strong> ${parts[1] || ''}</li>`;
    }).join('');

    renderIterationsStrip(p.thumbs);
    loadIterationSlide(0);

    overlay.scrollTop = 0;
    overlay.classList.add('is-active');
    overlay.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  };

  function renderIterationsStrip(thumbs) {
    itStrip.innerHTML = '';
    thumbs.forEach((t, i) => {
      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'it-mini-item' + (i === 0 ? ' active' : '');
      item.style.background = t.bg;
      showArtwork(item, t.image, "");
      item.setAttribute('aria-label', `View image ${i + 1}`);
      item.onclick = () => loadIterationSlide(i);
      itStrip.appendChild(item);
    });
  }

  function loadIterationSlide(i) {
    activeSlide = i;
    const p = projects[activePIndex];
    const t = p.thumbs[i];

    itCanvasBg.style.background = t.bg;
    showArtwork(itCanvasBg, t.image, t.alt);
    itPrev.hidden = itNext.hidden = p.thumbs.length < 2;
    itCount.textContent = `${i + 1 < 10 ? '0' : ''}${i + 1} / ${String(p.thumbs.length).padStart(2, '0')}`;

    const items = itStrip.querySelectorAll('.it-mini-item');
    items.forEach((it, idx) => {
      if (idx === i) {
        it.classList.add('active');
        itStrip.scrollTo({ left: it.offsetLeft - itStrip.offsetLeft - (itStrip.clientWidth - it.clientWidth) / 2, behavior: motionPreference.matches ? 'auto' : 'smooth' });
      } else {
        it.classList.remove('active');
      }
    });
  }

  itPrev.onclick = () => {
    const p = projects[activePIndex];
    activeSlide = (activeSlide - 1 + p.thumbs.length) % p.thumbs.length;
    loadIterationSlide(activeSlide);
  };

  itNext.onclick = () => {
    const p = projects[activePIndex];
    activeSlide = (activeSlide + 1) % p.thumbs.length;
    loadIterationSlide(activeSlide);
  };

  closeBtn.onclick = closeOverlayModal;

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeOverlayModal();
  });

  function closeOverlayModal() {
    overlay.classList.remove('is-active');
    overlay.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  prevProjBtn.onclick = () => {
    const prev = (activePIndex - 1 + projects.length) % projects.length;
    openProjectModal(prev);
  };

  nextProjBtn.onclick = () => {
    const next = (activePIndex + 1) % projects.length;
    openProjectModal(next);
  };

  document.querySelectorAll('.work-entry-card, .service-entry-row').forEach((el, i) => {
    el.tabIndex = 0;
    el.setAttribute('role', 'button');
    if (el.classList.contains('work-entry-card')) el.setAttribute('aria-label', `Open project ${i + 1}`);
    el.addEventListener('keydown', e => {
      if (e.target === el && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); el.click(); }
    });
  });

  // 6. BRIEF MODAL & EMAIL GENERATION
  const briefModal = document.getElementById('briefModalOverlay');
  const closeBriefBtn = document.getElementById('closeBriefModalBtn');
  const scopeSelect = document.getElementById('bmScope');
  const briefForm = document.getElementById('editorialBriefForm');

  document.querySelectorAll('.trigger-brief').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const s = btn.getAttribute('data-scope') || 'Single Thumbnail ($60)';

      let matched = false;
      for (let opt of scopeSelect.options) {
        if (opt.value === s || opt.value.includes(s)) {
          scopeSelect.value = opt.value;
          matched = true;
          break;
        }
      }
      if (!matched) scopeSelect.value = "Direct Inquiry";

      closeOverlayModal();
      briefModal.classList.add('is-active');
      briefModal.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
    });
  });

  closeBriefBtn.onclick = () => {
    briefModal.classList.remove('is-active');
    briefModal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  };

  briefModal.addEventListener('click', (e) => {
    if (e.target === briefModal) {
      briefModal.classList.remove('is-active');
      briefModal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }
  });

  briefForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('bmName').value;
    const email = document.getElementById('bmEmail').value;
    const channel = document.getElementById('bmChannel').value;
    const link = document.getElementById('bmLink').value;
    const pkg = scopeSelect.value;
    const deadline = document.getElementById('bmDeadline').value;
    const details = document.getElementById('bmDetails').value;
    const notes = document.getElementById('bmNotes').value;

    const emailSubject = `[Project Brief] ${pkg} — ${name} (${channel})`;
    const emailBody = `MOHAMED SEIF — PRODUCTION INTAKE BRIEF\n\n` +
      `Name: ${name}\n` +
      `Email: ${email}\n` +
      `YouTube Channel: ${channel}\n` +
      `Reference Video: ${link || 'N/A'}\n` +
      `Selected Scope: ${pkg}\n` +
      `Target Deadline: ${deadline || 'Flexible'}\n\n` +
      `Project Premise & Details:\n${details}\n\n` +
      `Additional Notes:\n${notes || 'None'}\n`;

    window.location.href = `mailto:mhmd828827@gmail.com?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
    
    alert(`Thank you, ${name}! Your brief has been formatted. Opening your email client to send.`);
    briefModal.classList.remove('is-active');
    document.body.style.overflow = '';
    briefForm.reset();
  });

  // Global ESC key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeOverlayModal();
      briefModal.classList.remove('is-active');
      document.body.style.overflow = '';
    }
  });

  const dialogs = [overlay, briefModal];
  let returnFocus = null;
  let activeDialog = null;
  const focusables = el => Array.from(el.querySelectorAll('button, a[href], input, select, textarea, [tabindex="0"]')).filter(e => !e.disabled && e.getClientRects().length);
  dialogs.forEach((dialog, i) => {
    dialog.setAttribute('role','dialog');
    dialog.setAttribute('aria-modal','true');
    dialog.setAttribute('aria-label', i ? 'Project brief' : 'Project images');
    dialog.inert = true;
    new MutationObserver(() => {
      const isOpen = dialog.classList.contains('is-active');
      dialog.inert = !isOpen;
      dialog.setAttribute('aria-hidden', String(!isOpen));
      if (isOpen && activeDialog !== dialog) {
        if (!activeDialog) returnFocus = document.activeElement;
        activeDialog = dialog;
        requestAnimationFrame(() => (i ? closeBriefBtn : closeBtn).focus({preventScroll:true}));
      } else if (!isOpen && activeDialog === dialog) {
        activeDialog = null;
        if (!dialogs.some(d => d.classList.contains('is-active'))) returnFocus?.focus({preventScroll:true});
      }
    }).observe(dialog, {attributes:true,attributeFilter:['class']});
  });
  document.addEventListener('keydown', e => {
    if (e.key !== 'Tab' || !activeDialog) return;
    const items = focusables(activeDialog);
    const first = items[0], last = items[items.length-1];
    if (!activeDialog.contains(document.activeElement)) {e.preventDefault();first.focus();}
    else if (e.shiftKey && document.activeElement === first) {e.preventDefault();last.focus();}
    else if (!e.shiftKey && document.activeElement === last) {e.preventDefault();first.focus();}
  });

});
